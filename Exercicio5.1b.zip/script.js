const nomes = ["Alface", "Banana", "Cenoura", "Tomate"];
const categorias = ["Verdura", "Fruta", "Legume", "Legume"];
const precos = ["R$ 3,50 a unidade", "R$ 7,90 o kg", "R$ 5,99 o kg", "R$ 8,49 o kg"];
const estoques = ["40 unidades", "85 kg", "60 kg", "52 kg"];
const imagens = ["🥬", "🍌", "🥕", "🍅"];

const selectProdutos = document.getElementById("selectProdutos");
const btnDetalhes = document.getElementById("btnDetalhes");
const divCategoria = document.getElementById("divCategoria");
const divPreco = document.getElementById("divPreco");
const divEstoque = document.getElementById("divEstoque");
const divImagem = document.getElementById("divImagem");

btnDetalhes.addEventListener("click", function () {
    const index = selectProdutos.value;

    if (index !== "") {
        divCategoria.textContent = categorias[index];
        divPreco.textContent = precos[index];
        divEstoque.textContent = estoques[index];
        divImagem.innerHTML = '<span class="emoji" title="' + nomes[index] + '">' + imagens[index] + '</span>';
    }
});
